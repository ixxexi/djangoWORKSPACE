from django.contrib import admin
from .models import Auctions, Bids

admin.site.register(Auctions)
admin.site.register(Bids)
